# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import paramiko
import time

# Read IP addresses from a file
with open('ip_list.txt') as fname:
    ip_list = fname.read().splitlines()

# Read credentials from a file
with open('creds.txt') as creds:
    cred_rec = creds.read().splitlines()

def execute_commands_on_remote(hostname, port, username, password):
    print('Current hostname -->', hostname)
    
    # Create an SSH client
    ssh_client = paramiko.SSHClient()
    ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        # Connect to the remote server
        ssh_client.connect(hostname=hostname, port=port, username=username, password=password)

        chan = ssh_client.invoke_shell()
        time.sleep(1)

        # Command to get the hostname
        chan.send('show running-config | include hostname\n')
        time.sleep(2)
        hostname_output = chan.recv(9999).decode("utf-8")
        
        # Command to get the version
        chan.send('show version\n')
        time.sleep(2)
        version_output = chan.recv(9999).decode("utf-8")

        # Parse the outputs
        # Extract the hostname
        device_hostname = hostname_output.split()[-1] if hostname_output else 'N/A'

        # Initialize model and version variables
        model = "N/A"
        version = "N/A"
        
        # Extract model and version from version output
        for line in version_output.splitlines():
            # Adjust these conditions based on actual output lines
            if "Model" in line:
                model = line.split()[1]  # Adjust based on your device's output
            if "Version" in line or "IOS" in line:
                version = line.split()[-1]  # Adjust based on your device's output
        
        # Save the results to a file
        with open(f'{device_hostname}.txt', 'w') as output_file:
            output_file.write(f"Hostname: {device_hostname}\n")
            output_file.write(f"Model: {model}\n")
            output_file.write(f"Version: {version}\n")
        
        print('Finished fetching info for -->', device_hostname)
        
    except Exception as e:
        print(f"An error occurred: {e}")
    finally:
        # Close the SSH connection
        ssh_client.close()
        print("Connection closed")

for ip in ip_list:
    # Define your remote server details
    port = 22  # Default SSH port
    username = cred_rec[0]
    password = cred_rec[1]
    
    execute_commands_on_remote(ip, port, username, password)
