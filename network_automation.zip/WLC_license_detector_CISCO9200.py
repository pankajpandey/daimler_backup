from netmiko import ConnectHandler

import re
import os
import sys
import getpass
import telnetlib
import pandas as pd

username = "apac\pvenka2"         # Replace with your username
password = "Ccnov@2024"      # Replace with your password

commands = [
    "install remove inactive",  # Clean-up command
    "y",
    "wr me",
    "sh log",                   # Logs verification commands
    "sh log | i flash",
    "sh log | i memory",
    "sh clock",
]

print('========================== Initiated ======================')
import paramiko
import time

# Read IP addresses from a file
with open('wlc_ip_list.txt') as fname:
    ip_list = fname.read().splitlines()


# Function to execute commands on a Cisco device
def execute_commands_on_cisco(hostname, username, password, commands):
    try:
        # Create an SSH client
        ssh_client = paramiko.SSHClient()
        ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh_client.connect(hostname, username=username, password=password, look_for_keys=False, allow_agent=False)
        
        print(f"Connected to hostname successfully--> {hostname}")
        
        # Start an interactive shell session
        shell = ssh_client.invoke_shell()
        
        for command in commands:
            shell.send(command + "\n")
            time.sleep(2)  # Wait for the command to execute
            output = shell.recv(5000).decode('utf-8')
            #print(f"Command: {command}\nOutput:\n{output}\n")
            print (f"command executed successfully--->{hostname}")
            with open(f'cisco_9200_slash_memory.txt', 'a') as output_file:
                output_file.write(f"Hostname : {hostname}\n")
        
        # Close the connection
        ssh_client.close()
        print(f"Disconnected from {hostname}")
        
    except Exception as e:
        print(f"An error occurred: {e}")


# Execute the commands
for hostname in ip_list:
    print (f"current hostname--->{hostname}")
    execute_commands_on_cisco(hostname, username, password, commands)


print ('------------------finished-----------------------------------')
