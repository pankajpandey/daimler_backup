// A closure is the combination of a function bundled together (enclosed) with references to its surrounding state (the lexical environment). 
// When you create a closure, you gain access to an outer function’s scope from an inner function. Closures are automatically created every time a function is defined in JavaScript.


function outerFunction(outerVariable) {
    return function innerFunction(innerVariable) {
        console.log(`Outer Variable: ${outerVariable}`);
        console.log(`Inner Variable: ${innerVariable}`);
    };
}

const newFunction = outerFunction("outside");
newFunction("inside");  // Output: Outer Variable: outside, Inner Variable: inside


