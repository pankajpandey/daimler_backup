// client <----> server (statefull & bidirectional connection between client & server)

