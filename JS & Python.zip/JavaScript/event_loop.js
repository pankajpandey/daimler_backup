// JavaScript’s event loop is the core mechanism that enables asynchronous operations.


// How do Event loops work?
// Call Stack:
// JavaScript uses a call stack to keep track of the currently executing function (where the program is in its execution).
// Callback Queue:
// Asynchronous operations, such as I/O operations or timers, are handled by the browser or Node.js runtime. When these operations are complete, corresponding functions (callbacks) are placed in the callback queue.
// Event Loop:
// The event loop continuously checks the call stack and the callback queue. If the call stack is empty, it takes the first function from the callback queue and pushes it onto the call stack for execution.


console.log("Before delay");

function delayBySeconds(sec) {
   let start = now = Date.now()
   while(now-start < (sec*1000)) {
     now = Date.now();
   }
}

delayBySeconds(5);

// Executes after delay of 5 seconds
console.log("After delay"); 