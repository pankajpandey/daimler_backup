
const my_list = [1,2,3,4,5]
const output = my_list.filter(function(d){ return d % 2 === 0 })
console.log('filter output--->'+output)

//arrow function
const output2 = my_list.filter(d => d % 2 === 0)
console.log('filter output--->'+output2)