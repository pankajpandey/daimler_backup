// Synchronous functions are executed in sequence, blocking subsequent code until the current one finishes.
// Asynchronous functions allow the program to continue running other tasks while waiting for the asynchronous operation to complete.

function synchronousFunction() {
    console.log("Step 1: Start");
    console.log("Step 2: Middle");
    console.log("Step 3: End");
  }
synchronousFunction();

  
//////////////////////////////////////////////////////////////////////////////
function asynchronousFunction() {
    console.log("Step 1: Start");

    setTimeout(() => {
        console.log("Step 2: Middle (async)");
    }, 2000);

    console.log("Step 3: End");
}

asynchronousFunction();
  