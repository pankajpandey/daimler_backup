// JavaScript Hoisting is the behavior where the interpreter moves function and variable declarations to the top of their respective scope before executing the code. 
// This allows variables to be accessed before declaration, aiding in more flexible coding practices and avoiding “undefined” errors during execution.

//only var gets hoisted but not const & let
a = 10
console.log('a--->'+a)

var a;