// var:
// Function level scope i.e. cannot be accessed out of function
// Can be re-declared and updated.
// Hoisted to the top of its scope and initialized with undefined.
var name='pankaj'
function printName(){
    var name ='pankaj'
    var name ='pandey'
    console.log('var name-->'+name)
}
printName()




// let:
// Block-scoped.
// Cannot be re-declared in the same scope, but can be updated.
// Hoisted to the top of its block scope, but not initialized.
// let name='pankaj'
// function printName(){
//     let name ='pankaj2'
//     console.log('let name-->'+name)
// }
// printName()


// const:
// Block-scoped.
// Cannot be re-declared or updated.
// Must be initialized at the time of declaration.
// const name='pankaj'
// function printName(){
//     name='pandey'
//     console.log('const name-->'+name)
// }
// printName()
//--->Uncaught TypeError TypeError: Assignment to constant variable.