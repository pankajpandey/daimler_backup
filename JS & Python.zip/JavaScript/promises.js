// A promise is an object that represents the completion or failure of an asynchronous operation and its resulting value. 
// Promises have three states: pending, fulfilled, and rejected

let myPromise = new Promise((resolve, reject) => {
    let success = true;
    if (success) {
        resolve("Promise fulfilled!");
    } else {
        reject("Promise rejected!");
    }
});

myPromise
    .then((message) => {
        console.log(message);  // Output: Promise fulfilled!
    })
    .catch((message) => {
        console.log(message);  // Output: Promise rejected!
    });
