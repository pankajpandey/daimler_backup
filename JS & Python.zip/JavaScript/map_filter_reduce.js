//map - transform a list
// const my_list = [1,2,3,4,5]
// const output = my_list.map(function(d){ return d*2 })
// console.log('map output--->'+output)

// reduce - to find max or sum 
const my_list = [1,2,3,4,5]
const output = my_list.reduce(function(acc, curr){ return acc + curr },0)
console.log('reduce output--->'+ output)
 
//filter - filter the values from list
// const my_list = [1,2,3,4,5]
// const output = my_list.filter(function(d){ return d % 2 === 0 })
// console.log('filter output--->'+output)