// call invokes a function with a specified this value and arguments provided one by one.
// apply is similar to call, but takes arguments as an array.
// bind creates a new function that, when called, has its this keyword set to the provided value.



//call
// let nameObj = { 
//     name: "Tony"
// } 
  
// let PrintName = { 
//     name: "steve", 
//     sayHi: function (age) { 
//         console.log('output of bind--->'+this.name + " age is " + age); 
//     } 
// } 
  
// PrintName.sayHi.call(nameObj, 42);



//apply
let nameObj = { 
    name: "Tony"
} 
  
let PrintName = { 
    name: "steve", 
    sayHi: function (...age) { 
        console.log('output of apply--->'+this.name + " age is " + age); 
    } 
} 
PrintName.sayHi.apply(nameObj, [42]);


///////////////////////////////////////////////////////////////////////////
//bind
// let nameObj = { 
//     name: "Tony"
// } 
  
// let PrintName = { 
//     name: "steve", 
//     sayHi: function () {   
//         // Here "this" points to nameObj 
//         console.log('output of bind--->'+this.name);  
//     } 
// } 
  
// let HiFun = PrintName.sayHi.bind(nameObj); 
// HiFun();