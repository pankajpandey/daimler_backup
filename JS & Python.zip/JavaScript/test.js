let total = (a,b) => {
    c = a+b
    console.log('c--->'+c)
}

total(10,30)