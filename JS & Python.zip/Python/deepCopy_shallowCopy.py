# shallow copy changes the original nested elements i.e. of child list
# deep copy does not affect orignal nested elements i.e. of child list
import copy  
  
import copy

# Original list
original_list = [1, 2, [3, 4]]
shallow_copy = copy.copy(original_list)

# Modify the inner list in the original list
original_list[2][0] = 'changed'

print("Original List:", original_list)  # Output: [1, 2, ['changed', 4]]
print("Shallow Copy:", shallow_copy)    # Output: [1, 2, ['changed', 4]]

print ('=============================================================')


##Deep Copy
# Original list
original_list = [1, 2, [3, 4]]
deep_copy = copy.deepcopy(original_list)

# Modify the inner list in the original list
original_list[2][0] = 'changed'

print("Original List:", original_list)  # Output: [1, 2, ['changed', 4]]
print("Deep Copy:", deep_copy)          # Output: [1, 2, [3, 4]]