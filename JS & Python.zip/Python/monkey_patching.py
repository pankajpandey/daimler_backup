# Monkey patching in Python refers to the dynamic modification of a class or module at runtime. 
# This can be useful for altering or extending the behavior of existing code without modifying its source code directly.

class MyClass:
    def add(self,a,b):
        c = a+b
        print("c-->",c)

# Create an instance of MyClass
obj = MyClass()
obj.add(1,2)  # Output: This is the original method.

def subtract(self,a,b):
    c = a-b
    print("c--->",c)

# Monkey patch the method
MyClass.add = subtract

# Create a new instance of MyClass
obj2 = MyClass()
obj2.add(3,1)  # Output: This is the new method.
