# In pass by reference, value gets changed from both the places

## Pass by Reference
def test(student):
    new = {'Sam':20, 'Steve':21}
    student.update(new)
    print("Inside the function pass by ref", student)
    return 

student = {'Jim': 12, 'Anna': 14, 'Preet': 10}
test(student)
print("Outside the function pass by ref:", student)


## Pass by value
def test(student):
    student = {'Sam':20, 'Steve':21}
    print("Inside the function", student)
    return 

student = {'Jim': 12, 'Anna': 14, 'Preet': 10}
test(student)
print("Outside the function:", student)