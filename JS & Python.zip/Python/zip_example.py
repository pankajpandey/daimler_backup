# The zip function in Python is used to combine multiple iterables (like lists or tuples) element-wise into a single iterable of tuples.

# Two lists
list1 = [1, 2, 3]
list2 = ['a', 'b', 'c']

# Using zip to combine them
zipped = zip(list1, list2)

# Converting the zip object to a list of tuples for easy viewing
zipped_list = list(zipped)

print(zipped_list)  # Output: [(1, 'a'), (2, 'b'), (3, 'c')]
