# The Walrus Operator allows you to assign a value to a variable within an expression. 
# This can be useful when you need to use a value multiple times in a loop, but don’t want to repeat the calculation.

names = ["Jacob", "Joe", "Jim"]

if (name := input("Enter a name: ")) in names:
    print(f"Hello, {name}!")
else:
    print("Name not found.")