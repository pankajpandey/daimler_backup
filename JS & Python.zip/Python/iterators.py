# we can convert any list or string to an iterator using 'iter' keyword. 
my_list = [1,2,3,4]
iter_obj = iter(my_list)

print ('iter_obj-->', next(iter_obj))
print ('iter_obj-->', next(iter_obj))




# Key Differences
# Creation:
# Iterator: Created from an iterable using the iter() function.
# Generator: Created using a function with the yield keyword.


# Memory Usage:
# Iterator: May use more memory if the iterable is large.
# Generator: More memory efficient because values are generated on the fly.

# Syntax:
# Iterator: Typically involves using the "iter()"" and "next()" methods.
# Generator: Defined using a function with "yield".

# Reusability:
# Iterator: Can be reused by calling iter() again on the iterable list.
# Generator: Cannot be reused once exhausted; a new generator needs to be created.