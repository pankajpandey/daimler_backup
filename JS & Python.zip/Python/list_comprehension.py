import time

# Using list comprehension
start_time = time.time()
comprehension_list = [x for x in range(1000000)]
comprehension_time = time.time() - start_time

# Using a normal for loop
start_time = time.time()
normal_list = []
for x in range(1000000):
    normal_list.append(x)
normal_time = time.time() - start_time

print(f"List comprehension time: {comprehension_time} seconds")
print(f"Normal list creation time: {normal_time} seconds")
