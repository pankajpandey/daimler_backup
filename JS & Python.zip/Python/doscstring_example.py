def add(a,b):
    '''this methos is used for adding two variables'''
    c = a+b
    print (c) 

add(1,2)
print ('doc comments-->', add.__doc__)