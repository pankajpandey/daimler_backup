# Pickle is a module in Python used for serializing and deserializing Python objects. Serialization (pickling) is the process of converting a Python object into a byte stream, and deserialization (unpickling) is the process of converting the byte stream back into a Python object.

import pickle

# Create a Python object
data = {'name': 'Alice', 'age': 25, 'is_student': True}

# Serialize the object to a file
with open('data.pkl', 'wb') as file:
    pickle.dump(data, file)
print("Data has been pickled.")

print ('=======================================================================')
# Deserialize the object from the file
with open('data.pkl', 'rb') as file:
    loaded_data = pickle.load(file)

print("Data has been unpickled.")
print(loaded_data)