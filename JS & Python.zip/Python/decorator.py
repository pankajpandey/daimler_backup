#Decorators are a very powerful and useful tool in Python since it allows programmers to modify the behaviour of a function or class.

#we can extend the greet()'s functionality without modifying. We just need to pass it to another function


def mydecorator(func):
    def inner_function():        
        func()
        print('How are you?')
    return inner_function

@mydecorator
def greet():
	print('Hello! ')

greet()