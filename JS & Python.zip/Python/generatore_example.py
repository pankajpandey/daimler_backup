def generate_number():
    for i in range(0,10000):
        yield i

numbers = generate_number()
print (next(numbers))
print (next(numbers))

