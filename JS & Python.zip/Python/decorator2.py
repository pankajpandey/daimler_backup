
import time
def addLogger(func):
    def wrapper():
        curre_time = time.time()
        print ('login method was executed at -->',curre_time)
        func()
    return wrapper

@addLogger
def loginForm():
    print ('inside login method')

loginForm()