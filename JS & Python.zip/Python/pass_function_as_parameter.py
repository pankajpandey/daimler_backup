def add(a,b):
    c= a+b
    print ('c--->',c)

def methodAcceptor(method_args):
    print ('method_args--->',method_args)


##passing add() method as parameter    
c = methodAcceptor(add(2,2))
