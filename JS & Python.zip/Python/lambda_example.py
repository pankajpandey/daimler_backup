def add(a,b):
    c = a+b
    print ('c--->',c)

    d = lambda a,b, c :a + b + c
    print ('d--->',d(10,20,30))

add(2,3)