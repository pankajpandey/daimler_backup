# In Python, access specifiers are public, protected, and private.

#Public --> By default, all attributes and methods in a Python class are public, meaning they can be accessed from outside the class
class MyClass:
    def __init__(self, name):
        self.name = name  # Public attribute

    def greet(self):
        return f"Hello, {self.name}!"  # Public method

# Using the class
obj = MyClass("Alice")
print(obj.name)        # Output: Alice
print(obj.greet())     # Output: Hello, Alice!

print ('==================================================================================')

#protected --> the attribute or method is intended for internal use or for use by subclasses
class MyClass:
    def __init__(self, name):
        self._name = name  # Protected attribute

    def _greet(self):
        return f"Hello, {self._name}!"  # Protected method

# Using the class
obj = MyClass("Bob")
print(obj._name)       # Output: Bob (still accessible)
print(obj._greet())    # Output: Hello, Bob! (still callable)

print ('================================================================')

#private -> This causes the interpreter to rewrite the attribute name in a way that makes it harder to create collisions when the class is extended later. However, it does not truly prevent access from outside the class.
class MyClass:
    def __init__(self, name):
        self.__name = name  # Private attribute

    def __greet(self):
        return f"Hello, {self.__name}!"  # Private method

# Using the class
obj = MyClass("Charlie")
# Accessing private attribute directly will raise an AttributeError
# print(obj.__name)  # This would raise an AttributeError
# Accessing private method directly will raise an AttributeError
# print(obj.__greet())  # This would raise an AttributeError

# Accessing through name mangling
print(obj._MyClass__name)     # Output: Charlie
print(obj._MyClass__greet())  # Output: Hello, Charlie!



