


def printValues(myList):
    print ('received',myList)
    myList['name']='Dharam'

myList = {'name':'pankaj', 'lastname':'pandey'}
print ('before-->',myList)
printValues({'name':'pankaj', 'lastname':'pandey'})
print ('after-->',myList)