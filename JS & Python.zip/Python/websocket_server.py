import asyncio
from websockets.server import serve

async def echo(websocket):
    async for message in websocket:
        if message == 'How are you':
            res = 'I am fine.. Thank you'
        elif message == 'How many alarms this year':
            res = 'Total 200 alarms'
        else:
            res = 'CCOpsView still learning your question'
        await websocket.send('CCOpsView Response:'+res)

async def main():
    async with serve(echo, "localhost", 8765):
        await asyncio.Future()  # run forever

asyncio.run(main())