from websockets.sync.client import connect

def hello():
    with connect("ws://localhost:8765") as websocket:
        websocket.send("How are you")
        message = websocket.recv()
        print(f"CCOpsView Response: {message}")

hello()