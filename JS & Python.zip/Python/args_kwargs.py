def add(*args):
    print ('args--->',args)

add(1,2,3)


def add_dict(*kwargs):
    print ('kwargs-->',kwargs[0]['name'])

add_dict({'name':'pankaj'})