from netmiko import ConnectHandler

import re
import os
import sys
import getpass
import telnetlib
import pandas as pd


print('========================== Initiated ======================')
import paramiko
import time
import subprocess

# Read IP addresses from a file
with open('ip_list.txt') as fname:
    ip_list = fname.read().splitlines()


# Lists to store results
success_list = []
failure_list = []

def ping_device(device):
    try:
        # Ping command, suppressing output
        response = subprocess.run(["ping", "-c", "1", "-W", "1", device],
                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if response.returncode == 0:
            return True
        else:
            return False
    except Exception as e:
        print(f"Error pinging {device}: {e}")
        return False

for ip_address in ip_list:
    if ping_device(ip_address):
        success_list.append(ip_address)
    else:
        failure_list.append(ip_address)

print (f"success_list--->{success_list}")
print (f"failure_list--->{failure_list}")


print ('------------------finished-----------------------------------')
