import json
import time
from netmiko import ConnectHandler
from paramiko import SSHClient
from scp import SCPClient
import difflib
import pandas as pd
from paramiko import SSHClient, AutoAddPolicy
from scp import SCPClient
import paramiko
import socket
import re


def check_flash_space(host, user, password):
    try:
        print ('inside checking check_flash_space')
        print (f'host-->{host}, user-->{user}, password-->{password}')
        # Create SSH connection
        # Establish SSH Connection
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(host, username=user, password=password, timeout=10)
        print ('SSH connectivity successful')
        
        # Run command
        cmd = 'show flash:'
        stdin, stdout, stderr = client.exec_command(cmd)
        output = stdout.read().decode()

        # Close connection
        client.close()

        # Extract available space using regex
        match = re.search(r'(\d+)\s+bytes\s+available', output)
        if match:
            available_space = int(match.group(1))
            print(f"Available Flash Memory: {available_space} bytes")
        else:
            print("Could not determine available flash space.")
    except Exception as e:
        print(f"Oopss.Failed to fetch the device flash memeory available space details: {e}")



# Function to connect to device
def connect_to_device(device):
    return ConnectHandler(
        device_type="cisco_ios",
        host=device["ip"],
        username=device["username"],
        password=device["password"]
    )


def get_tftp_ip():
    try:
        print ('Inside trying to extract IP of the TFTP server')
        system_hostname = socket.gethostname()
        tftp_host = system_hostname  # Replace with actual hostname
        tftp_ip = socket.gethostbyname(tftp_host)
        return tftp_ip
    except Exception as e:
        print("Oops..Failed to extract IP address of the TFTP server:", e)
        return None

tftp_server = get_tftp_ip()
print("TFTP Server IP:", tftp_server)


# Function to transfer file using SCP
def transfer_file(device, ios_image):
    try:
        print (f'device--->{device}')
        print (f'ios_image--->{ios_image}')
        print (f'tftp_server--->{tftp_server}')
        
    
        # Establish SSH Connection
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(device["ip"], username=device["username"], password=device["password"], timeout=10)
        print ('SSH connectivity successful')
        
        # Open interactive shell
        shell = ssh.invoke_shell()
        time.sleep(1)
        #tftp_server = '\\sedc266f.edc.corpintra.net\ESTR_G18800\GNOC-MBRDI\IOS-Images\CCOpsView\'
        # Send copy command with automatic destination path
        print ('Trying to copy the file to device flash memory....')
        shell.send(f"copy tftp://{tftp_server}/{ios_image} flash:{ios_image}\n")
        time.sleep(2)  # Wait for response

        # Handle prompts
        shell.send("\n")  # Press Enter for destination filename prompt
        time.sleep(5)  # Wait for file transfer

        # Read output
        output = shell.recv(5000).decode('utf-8')
        print ('Image Copy successful...')
        print("Output from device:\n", output)

        # Close connections
        ssh.close()


        if "Error" in output or "failed" in output.lower():
            print("Failed to transfer file via TFTP:")
        else:
            print("File has been transferred successfully to device flash memory")

    except Exception as e:
        print("Failed to transfer file -->", e)


# Load device details
with open("devices.json", "r") as file:
    devices = json.load(file)
    
for device in devices:
    print(f"Upgrading {device['hostname']}...")
    # Step 2: Transfer IOS Image
    
    hostname = device['ip']
    username = device["username"]
    password = device["password"]
    
    check_flash_space(hostname, username, password)
    #(device, device["ios_image"])
    
    print(f"Upgrade complete for {device['hostname']}.")

print("All upgrades completed.")
