import json
import time
from netmiko import ConnectHandler
from paramiko import SSHClient
from scp import SCPClient
import difflib
import pandas as pd
from paramiko import SSHClient, AutoAddPolicy
from scp import SCPClient
import paramiko
import socket
import re
import traceback


def get_tftp_ip():
    try:
        print ('Inside trying to extract IP of the TFTP server')
        print (f"============================================================")
        system_hostname = socket.gethostname()
        tftp_host = system_hostname  # Replace with actual hostname
        tftp_ip = socket.gethostbyname(tftp_host)
        print (f'tftp_ip-->{tftp_ip}')
        print (f"============================================================")
        return tftp_ip
    except Exception as e:
        print("Oops..Failed to extract IP address of the TFTP server:", e)
        return None
    
def bytes_to_mb_gb(size_in_bytes):
    try:
        """Convert bytes to MB and GB."""
        mb = size_in_bytes / (1024 * 1024)
        gb = size_in_bytes / (1024 * 1024 * 1024)
        return round(mb, 2), round(gb, 2)
    except Exception as e:
        print (f"Oops..Failed to convert bytes to MB/BG-->{e}")

def check_flash_space(ip_address, user, passwd):
    try:
        print (f"====================================================")
        print('Inside checking check_flash_space')
        print(f'ip_address --> {ip_address}, user --> {user}, password --> {passwd}')


        # Create SSH connection
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        # Establish SSH Connection
        client.connect(ip_address, username=user, password=passwd, timeout=10)
        print('SSH connectivity successful')

        # Run command
        cmd = 'show flash:'
        stdin, stdout, stderr = client.exec_command(cmd)
        output = stdout.read().decode()

        # Close connection
        client.close()

        # Extract total and available memory
        total_used_bytes = re.search(r'(\d+)\s+bytes\s+used', output)
        available_match = re.search(r'(\d+)\s+bytes\s+available', output)

        if total_used_bytes and available_match:
            total_memory = int(total_used_bytes.group(1))
            available_memory = int(available_match.group(1))

            total_mb, total_gb = bytes_to_mb_gb(total_memory)
            available_mb, available_gb = bytes_to_mb_gb(available_memory)

            print(f"Total Used Memory: {total_memory} bytes | {total_mb} MB | {total_gb} GB")
            print(f"Total Available Memory: {available_memory} bytes | {available_mb} MB | {available_gb} GB")
            print (f"====================================================")
        else:
            print("Could not determine used or available flash space.")

    except Exception as e:
        print(f"Oopss. Failed to fetch the device flash memory details: {e}")



def get_cisco_version(ip_address, user, passwd):
    try:
        print(f"Inside get_cisco_version")
        print (f"====================================================")
        print(f"Connecting to {ip_address}...")
        
        # Create SSH client
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        # Establish SSH connection
        client.connect(ip_address, username=user, password=passwd, timeout=10)
        print("SSH connection established.")

        # Run 'show version' command
        cmd = 'show version'
        stdin, stdout, stderr = client.exec_command(cmd)
        output = stdout.read().decode()

        # Close SSH connection
        client.close()

        # Extract Cisco version
        match = re.search(r'Cisco IOS XE Software,.*Version\s([\d\.]+)', output)
        if match:
            ios_version = match.group(1)
            print(f"Cisco IOS Version: {ios_version}")
            print (f"====================================================")
            return ios_version

        match = re.search(r'NX-OS.*version\s([\d\.]+)', output)
        if match:
            nxos_version = match.group(1)
            print(f"Cisco NX-OS Version: {nxos_version}")
            return nxos_version

        print("Could not determine Cisco version.")
        print (f"====================================================")
        return 'Cisco version not found'

    except Exception as e:
        print(f"Error fetching Cisco version: {e}")
        return 'Cisco version not found'


def get_bin_files(host, user, passwd, expected_version):
    try:
        print (f'inside get_bin_files')
        print (f"====================================================")
        print(f"Connecting to {host}...")
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(host, username=user, password=passwd, timeout=10)
        print('SSH connectivity successful')
        
        # Run command to get .bin files
        cmd = "show flash: | i bin"
        stdin, stdout, stderr = client.exec_command(cmd)
        output = stdout.read().decode()
        client.close()

        # Extract .bin filenames and versions
        bin_files = re.findall(r'(\S+\.bin)', output)

        matching_files = []
        non_matching_files = []

        for file in bin_files:
            match = re.search(r'(\d+\.\d+\.\d+)', file)  # Extract version (e.g., 17.09.05)
            if match:
                file_version = match.group(1)
                if file_version == expected_version:
                    matching_files.append(file)
                else:
                    non_matching_files.append(file)

        print(f"\nMatching bin Files ({expected_version}): {matching_files}")
        print(f"Non-Matching bin Files: {non_matching_files}")
        print (f"====================================================")

    except Exception as e:
        print(f"Error fetching .bin files: {e}")
        print (f"====================================================")



# Function to transfer file using SCP
def transfer_tftp_file(host, user, passwd, ios_image):
    try:
        print (f"inside transfer_tftp_file")
        print (f"============================================================================")
        
        print (f'target device--->{host}')
        print (f'ios_image--->{ios_image}')
        
        tftp_server_ip = get_tftp_ip()
        print (f'tftp_server_ip--->{tftp_server_ip}')
        
        
        # Establish SSH Connection
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(host, username=user, password=passwd, timeout=10)
        print ('SSH connectivity successful')
        
        # Open interactive shell
        shell = ssh.invoke_shell()
        time.sleep(1)
        #tftp_server = '\\sedc266f.edc.corpintra.net\ESTR_G18800\GNOC-MBRDI\IOS-Images\CCOpsView\'
        # Send copy command with automatic destination path
        print ('Trying to copy the file to device flash memory....')
        shell.send(f"copy tftp://{tftp_server_ip}/{ios_image} flash:{ios_image}\n")
        time.sleep(2)  # Wait for response

        # Handle prompts
        shell.send("\n")  # Press Enter for destination filename prompt
        time.sleep(5)  # Wait for file transfer

        # Read output
        file_transfer_status = shell.recv(5000).decode('utf-8')
        print (f"file_transfer_status -->{file_transfer_status}")
        print ('Image Copy successful...')
        print("Output from device:\n", file_transfer_status)
        
        # Close connections
        ssh.close()


        if "Error" in file_transfer_status or "failed" in file_transfer_status.lower():
            print("Failed to transfer file via TFTP:")
            print (f"============================================================================")
        else:
            print("File has been transferred successfully to device flash memory")
            print (f"============================================================================")

    except Exception as e:
        print("Failed to transfer file -->", e)
        print (f"============================================================================")


# Function to execute pre-checks
def execute_pre_check(host, user, passwd):
    try:
        print(f"Upgrading {host}...")
        print(f"Inside execute_pre_check for {host}")
        print("=" * 60)

        # Establish SSH Connection
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(host, username=user, password=passwd, timeout=10)
        print("✅ SSH connectivity successful")

        # Open Interactive Shell
        shell = ssh.invoke_shell()
        time.sleep(1)  # Allow shell to initialize
        shell.recv(1000)  # Clear buffer

        # Define Pre-Check Commands
        commands = [
            "terminal length 0",
            "show switch",
            "show ver => Imp",
            "show run => Imp",
            "show cdp nei => Imp",
            "show etherch summ",
            "show ip int bri => Imp",
            "show int des",
            "show int status => Imp",
            "show vlan => Imp",
            "show env all => Imp",
            "show power all => Imp",
            "show power inline",
            "show flash:",
            "show logging",
            "show boot",
            "sh module => Imp",
            "sh lldp neig",
            "sh arp",
            "sh inv",
            "show mac address-table => Imp",
            "sh ip route",
            "sh int des",
            "sh redun",
            "show ip dhcp snooping",
            "sh clock",
            "wr memory"
        ]

        output = ""

        for cmd in commands:
            try:
                cmd_clean = cmd.replace(" => Imp", "").strip()  # Remove '=> Imp' for execution

                shell.send(cmd_clean + "\n")
                time.sleep(2)  # Wait for command execution
                result = shell.recv(10000).decode(errors='ignore').strip()

                # Format output: Bold important commands
                if "=> Imp" in cmd:
                    output += f"\n** {cmd_clean} **\n{result}\n"
                else:
                    output += f"\n{cmd_clean}\n{result}\n"

            except Exception as cmd_error:
                print(f"❌ Failed to execute '{cmd_clean}': {cmd_error}")

        ssh.close()  # Close SSH connection

        # Save Pre-Check Output
        filename = f"{host}_pre_check.txt"
        with open(filename, "w", encoding="utf-8") as f:
            f.write(output)

        print(f"✅ Pre-check output saved successfully as {filename}")

    except Exception as e:
        print("❌ Oops! Failed to execute pre-check commands.")
        print("Error details:")
        traceback.print_exc()  # Print full error traceback
        
        
        
# Load device details
with open("devices.json", "r") as file:
    devices = json.load(file)
    
for device in devices:
    print(f"Upgrading {device['hostname']}...")
    # Step 2: Transfer IOS Image
    
    hostname = device['ip']
    username = device["username"]
    password = device["password"]
    ios_image = device["ios_image"]
    
    
    ## to get the cisco version (to execute the commands)
    #cisco_version = get_cisco_version(hostname,username,password)
    #print(f'cisco_version--->{cisco_version}')
    
           
    ## to get the space availability of flash
    #flash_space = check_flash_space(hostname,username,password)

    ## to get the bin files so that non-matching bin files can be deleted
    #flash_bin_files = get_bin_files(hostname,username,password, cisco_version)           
    
    ## to transfer the file via TFTP protocol
    #transfer_tftp_file(hostname,username,password, ios_image)
    
    
    ## execute_preCheck_commands and save the output in file
    execute_pre_check(hostname,username,password)
    
    print(f"Upgrade complete for {device['hostname']}.")






    