import json
import time
from netmiko import ConnectHandler
from paramiko import SSHClient
from scp import SCPClient
import difflib
import pandas as pd


def compare_pre_post(pre_upgrade_file, post_upgrade_file, output_html):
    with open(pre_upgrade_file, 'r') as pre_file:
        pre_lines = pre_file.readlines()

    with open(post_upgrade_file, 'r') as post_file:
        post_lines = post_file.readlines()

    diff = list(difflib.ndiff(pre_lines, post_lines))

    pre_html, post_html = "", ""

    for line in diff:
        clean_line = line[2:].strip()
        if line.startswith("- "):  # Removed lines
            pre_html += f"<tr><td class='removed'>{clean_line}</td><td></td></tr>"
        elif line.startswith("+ "):  # Added lines
            post_html += f"<tr><td></td><td class='added'>{clean_line}</td></tr>"
        elif line.startswith("  "):  # Unchanged lines
            pre_html += f"<tr><td>{clean_line}</td><td>{clean_line}</td></tr>"
        else:  # Possible modifications
            pre_html += f"<tr><td class='removed'>{clean_line}</td><td></td></tr>"

    html_content = f"""
    <html>
    <head>
        <title>IOS Upgrade Diff Report</title>
        <style>
            body {{ font-family: Arial, sans-serif; }}
            h1 {{ text-align: center; color: #2c3e50; }}
            table {{ width: 100%; border-collapse: collapse; }}
            th, td {{ border: 1px solid #ddd; padding: 8px; vertical-align: top; }}
            th {{ background-color: #f2f2f2; }}
            .removed {{ background-color: #f8d7da; }}
            .added {{ background-color: #d4edda; }}
        </style>
    </head>
    <body>
        <h1>IOS Upgrade Side-by-Side Comparison</h1>
        <table>
            <tr>
                <th>Pre-Upgrade</th>
                <th>Post-Upgrade</th>
            </tr>
            {pre_html + post_html}
        </table>
    </body>
    </html>
    """

    with open(output_html, 'w') as file:
        file.write(html_content)

    print(f"Diff report generated: '{output_html}'")

# Example usage
pre_upgrade_file = "53.48.245.13_pre.txt"
post_upgrade_file = "53.48.245.13_post.txt"
output_html = "comparison_report.html"
compare_pre_post(pre_upgrade_file, post_upgrade_file, output_html)