import paramiko
import time
import concurrent.futures
import os

# Read IPs from file
with open('password_change_ip_list.txt') as f:
    ip_list = f.read().splitlines()

# Read credentials from file
with open('password_change_creds.txt') as f:
    creds = f.read().splitlines()
username, password = creds[0], creds[1]

# Ensure output directories exist
os.makedirs('password_change', exist_ok=True)
os.makedirs('password_change_failed', exist_ok=True)

# Command to execute
command = "show run | incl username admin4"

# Expected substrings (partial match allowed)
expected_substrings = ["username admin4nccext privilege", "username admin4nccint privilege"]


def configure_device(hostname):
    print(f"🔄 Connecting to {hostname}...")
    ssh_client = paramiko.SSHClient()
    ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    try:
        ssh_client.connect(hostname, port=22, username=username, password=password, timeout=10)
        shell = ssh_client.invoke_shell()
        time.sleep(1)  # Allow shell to be ready

        shell.send(command + "\n")
        time.sleep(2)  # Allow time for execution

        output = shell.recv(5000).decode('utf-8', errors="ignore")  # Ignore decoding errors
        shell.send("exit\n")
        time.sleep(1)
        ssh_client.close()

        # Extract lines and check for expected substrings
        found_lines = [line.strip() for line in output.split('\n') if line.strip()]  # Strip whitespaces
        
        # Check if any line contains the expected substring
        matches = {expected: any(expected in line for line in found_lines) for expected in expected_substrings}

        if all(matches.values()):
            result = "✅ Both expected usernames found!"
            output_dir = 'password_change'
        else:
            result = "❌ Missing expected usernames!"
            output_dir = 'password_change_failed'
        
        print(f"{result} - {hostname}")
        with open(f'{output_dir}/{hostname}.txt', 'w', encoding="utf-8", errors="ignore") as f:
            f.write("Found lines:\n" + "\n".join(found_lines) + "\n\n" + result)

    except Exception as e:
        print(f"❌ Failed to check {hostname}: {str(e)}")
        with open(f'password_change_failed/{hostname}.txt', 'w', encoding="utf-8", errors="ignore") as f:
            f.write(f"Failed: {str(e)}\n")

    finally:
        ssh_client.close()


# Run commands in parallel using ThreadPoolExecutor
MAX_THREADS = 50  # Adjust based on system capability
with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
    executor.map(configure_device, ip_list)

print("🔥 Configuration Completed!")
