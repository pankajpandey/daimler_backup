import paramiko
import time
import concurrent.futures
import os

# Read IPs from file
with open('password_change_ip_list.txt') as f:
    ip_list = f.read().splitlines()

# Read credentials from file
with open('password_change_creds.txt') as f:
    creds = f.read().splitlines()
username, password = creds[0], creds[1]

# Ensure output directories exist
os.makedirs('password_change', exist_ok=True)
os.makedirs('password_change_failed', exist_ok=True)

# Commands to execute
commands = [
    "config t",
    "no username admin4nccext",
    "no username admin4nccint",
    "username admin4nccext privilege 15 secret RvdJ4dy#U!YrdnC",  
    "username admin4nccint privilege 15 secret Zj&wIfAL2jvDNm6",
    "end",  
    "write memory"  
]

# Function to execute SSH commands on a device
def configure_device(hostname):
    print(f"🔄 Connecting to {hostname}...")

    ssh_client = paramiko.SSHClient()
    ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    try:
        ssh_client.connect(hostname, port=22, username=username, password=password, timeout=10)
        shell = ssh_client.invoke_shell()
        time.sleep(1)  # Allow shell to be ready

        # Store full output
        full_output = []

        for cmd in commands:
            shell.send(cmd + "\n")
            time.sleep(1)  # Small delay for execution
            output = shell.recv(5000).decode('utf-8')  # Capture output
            full_output.append(f"\n# {cmd}\n{output.strip()}")  # Append command and output

        shell.send("exit\n")
        time.sleep(1)

        output_text = "\n".join(full_output)
        print(f"✅ Successfully configured {hostname}")

        # Write full session output to file
        with open(f'password_change/{hostname}.txt', 'w', encoding="utf-8") as f:
            f.write(output_text + "\n✅ Configuration Successful!")

    except Exception as e:
        error_message = f"❌ Failed to configure {hostname}: {str(e)}"
        print(error_message)
        
        with open(f'password_change_failed/{hostname}.txt', 'w', encoding="utf-8") as f:
            f.write(error_message + "\n")

    finally:
        ssh_client.close()

# **Run commands in parallel using ThreadPoolExecutor**
MAX_THREADS = 50  # Adjust based on system capability
with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
    executor.map(configure_device, ip_list)

print("🔥 Configuration Completed!")
